import Vue from 'vue'
import App from './home'

Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
})
